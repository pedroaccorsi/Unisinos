#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


#define gd_new_line printf("\n");


int main(int argc, char *argv[]){


	exit(0);
	
}
