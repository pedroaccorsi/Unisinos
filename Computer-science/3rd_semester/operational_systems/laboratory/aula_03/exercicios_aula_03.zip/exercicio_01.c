#include <stdio.h>
#include <string.h>

int main(){

    char string[500] = "Hello, World";
    float pi = 3.141581;

    printf("string: %s \npi: %.3f\n", string, pi);
    return 0;

}